package com.bupt.myapplication.object;


import java.util.List;

public class PageCoordinate {
    String paperType;
    String paperId;
    List<CenterPoint> centerPoints;

    public PageCoordinate(String paperType, String paperId, List<CenterPoint> centerPoints) {
        this.paperType = paperType;
        this.paperId = paperId;
        this.centerPoints = centerPoints;
    }

    public String getPaperType() {
        return paperType;
    }

    public String getPaperId() {
        return paperId;
    }

    public List<CenterPoint> getCenterPoints() {
        return centerPoints;
    }
}

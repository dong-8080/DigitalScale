package com.bupt.myapplication;

import android.Manifest;
import android.bluetooth.BluetoothGatt;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.bbb.bpen.binder.BiBiBinder;
import com.bbb.bpen.command.BiBiCommand;
import com.bbb.bpen.model.Pen;
import com.bbb.bpen.model.PointData;
import com.bbb.bpen.service.BluetoothLEService;
import com.bupt.myapplication.data.PointManager;
import com.bupt.myapplication.data.StorageStrokeManager;
import com.bupt.myapplication.object.StorageStroke;
import com.bupt.myapplication.util.StringUtils;
import com.bupt.myapplication.view.DrawingView;
import com.google.gson.Gson;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editText;
    private Button button;

    private Button button2;

    private Button button3;

    // import custom drawing view
    public DrawingView dw;

    private static String TAG = "MainActivityClass";

    public Handler BLEConnectHandler;

    static {
        System.loadLibrary("bbbdraw");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.edit_text);
        button = findViewById(R.id.button);
        button.setOnClickListener(this);

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(this);

        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(this);
        dw = findViewById(R.id.drawing_view);
        init();

    }

    private void init() {
        // 权限授予
        checkBluetoothPermission();

        // 初始化蓝牙笔连接service
        BLEConnectHandler = new Handler(Looper.getMainLooper());
        Intent intent = new Intent(this, BluetoothLEService.class);
        bindService(intent, coon, Context.BIND_AUTO_CREATE);
    }



    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button) {
            String macAddress = editText.getText().toString();
            BiBiCommand.connect(this, StringUtils.macConvert(macAddress), true);
//            Toast.makeText(MainActivity.this, "尝试连接蓝牙笔", Toast.LENGTH_SHORT).show();
        } else if (view.getId()==R.id.button2){
            BiBiCommand.startScanWithQueue(this);
        } else if (view.getId()==R.id.button3){
//            List<PointData> strokes = PointManager.getInstance().getAllPointScreenList();
            Log.e("123", "asd");
//            BiBiCommand.stopscan(MainActivity.this);

            // TODO:fix this
//            List<StorageStroke> storageStrokes = StorageStrokeManager.getInstance().getStorageStrokeList();
//            Gson gson = new Gson();
//            String str = gson.toJson(storageStrokes);
//            Log.e("Storage", str);
        }
    }


    com.bbb.bpen.delegate.BlueDelegate blueDelegate = new com.bbb.bpen.delegate.BlueDelegate() {
        @Override
        public void didDiscoverWithPen(Pen device, int rssi) {
            // 开启扫描后会调用此方法
            Log.e("discover", "discover Pen " + device.getAddress() + " rssi" + rssi);
        }

        @Override
        public void didConnectFail(BluetoothGatt gatt, int status, int newState) {
            Log.e(TAG, "didConnectFail, status:" + status + " newState:" + newState);
        }

        // 连接时的状态主要由以下两个回调函数判定
        // 接收到消息时得全局存储消息，以确定蓝牙笔是否连接
        @Override
        public void didDisconnect(Pen device, int status, int newState) {
            MyApp.getInstance().setCurMacAddress(null);
//            AudioPlayerManager.getInstance(MainActivity.this).playAudio(R.raw.ble_disconnected);

            Log.e(TAG, "didDisconnect, status:" + status + " newState:" + newState);
        }

        @Override
        public void didConnect(Pen device, int status, int newState) {
            MyApp.getInstance().setCurMacAddress(device.getAddress());

//            AudioPlayerManager.getInstance(MainActivity.this).playAudio(R.raw.ble_connected_success);

            Log.e(TAG, "didConnect, status:" + status + " newState:" + newState);
            Log.e(TAG, "didConnect, device mac:" + device.getAddress());
        }

        @Override
        public void notifyBattery(int battery) {
        }

        // 绘图重要函数
        @Override
        public void notifyRealTimePointData(List<PointData> pointDrawArray) {
            PointManager.getInstance().addPointToList(pointDrawArray);

            // 仅从最后一个点触发点击相关的广播事件
            // 第一个点触发页面切换事件
            if (pointDrawArray != null && pointDrawArray.size() > 0) {
                PointData startPoint = pointDrawArray.get(0);
                PointData endPoint = pointDrawArray.get(pointDrawArray.size() - 1);


                // 判定是否需要切换背景纸张，执行换页
                if (startPoint.isStroke_start() &&
                        !StringUtils.isStringEqual(startPoint.getPage_id(), MyApp.getInstance().getPaperid())) {

                    String newPaperId = String.valueOf(startPoint.getPage_id());
                    MyApp.getInstance().setPaperid(newPaperId);


                    Log.e("PaperChanged", "纸张切换");
                    dw.notifyChangeBackGround();

                } else {

                    dw.notifyDraw();
                    // 触发抬笔后的判定逻辑
                    // TODO: something caused error, fix this! 2023年12月4日
//                    if (endPoint.isStroke_end()){
//                        // 当前笔迹信息与纸张和控件id对应，即pageID-gridID-stroke_list
//                        List<PointData> strokes = PointManager.getInstance().getLatestStroke();
//                        StorageStrokeManager.getInstance().appendStroke(strokes);
//                    }
                }
            }

        }


        @Override
        public void notifyBatchPointData(List<PointData> pointDrawArray) {
        }

        @Override
        public void notifyFirmwareWithNewVersion(String newVersion) {
        }

        @Override
        public void notifyDataSynchronizationMode(int mode) {
        }

        @Override
        public void notifyContinueToUseSuccess() {
            Log.e(TAG, "notifyContinueToUseSuccess");
        }

        @Override
        public void notifyContinueToUseFail() {
            Log.e(TAG, "notifyContinueToUseFail");
        }

        @Override
        public void notifyBoundMobile(String mobile) {
        }

        @Override
        public void notifyModel(String model) {
            Log.e(TAG, "notifyModel:" + model);
        }

        @Override
        public void unsynchronizedDataWithPercentage(float percentage) {
        }

        @Override
        public void notifySyncComplete() {
        }

        @Override
        public void accelerometerDataSendFromPenOnXYZ(float x, float y, float z, int jiaodu) {
        }

        @Override
        public void notifyWrittingBatchPointData(List<PointData> pointDrawArray) {
        }

        @Override
        public void notifyOfflineBatchPointData(List<PointData> list, int i) {

        }

        @Override
        public void notifyCameraState() {
        }

        @Override
        public void notifyChargeState(int chargestatus) {
        }
    };


    private BluetoothLEService service = null;
    private ServiceConnection coon = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            BiBiBinder myBinder = (BiBiBinder) binder;
            service = myBinder.getService();
            service.setblueDelegate(blueDelegate);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.e(TAG, "onServiceDisconnected ");
        }
    };


    public static final int REQUEST_BLUETOOTH_PERMISSION = 310;
    private void checkBluetoothPermission() {
        // 检查蓝牙权限是否已授予
        // 写满权限
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED

        ) {
            // 权限未被授予，需要申请权限
//            Toast.makeText(this, "权限未被授予，需要申请权限", Toast.LENGTH_SHORT);
            ActivityCompat.requestPermissions(this, new String[]{
                    android.Manifest.permission.BLUETOOTH,
                    android.Manifest.permission.BLUETOOTH_ADMIN,
                    android.Manifest.permission.BLUETOOTH_CONNECT,
                    android.Manifest.permission.BLUETOOTH_SCAN,
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQUEST_BLUETOOTH_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_BLUETOOTH_PERMISSION) {

            // 0表示授权成功，-1失败，全都为0即成功
            int grantResultsSum = 0;
            for (int grantResult : grantResults) {
                grantResultsSum += grantResult;
            }
            if (grantResults.length > 0 && grantResultsSum == PackageManager.PERMISSION_GRANTED) {
                // 权限已被授予，可以进行蓝牙操作
                Log.e(TAG, "权限已被授予，可以进行蓝牙操作");
                for (int i = 0; i < grantResults.length; i++) {
                    Log.e(TAG, "permission " + permissions[i] + ":" + grantResults[i]);
                }
//                showPenBindingDialog();

            } else {
                // 权限被拒绝，无法执行蓝牙操作
                Log.e(TAG, "权限被拒绝，无法执行蓝牙操作");
                Toast.makeText(MainActivity.this, "权限被拒绝，无法执行蓝牙操作",
                        Toast.LENGTH_LONG).show();
                // 可以根据需要进行处理，例如显示一个提示信息或关闭应用程序
            }
        }
    }

}